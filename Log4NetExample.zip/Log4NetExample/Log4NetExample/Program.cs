﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Log4NetExample
{
    class Program
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        static void Main(string[] args)
        {
            log.Info("aaaaaaaaaa");
            NameValueCollection nvc = new NameValueCollection();
            nvc.Add("Upd", "abc");
            string updateQs = "";
            foreach (string key in nvc)
            {
                if (key.ToUpper() == "UPD")
                {
                    updateQs = "&upd=" + nvc[key];
                    break;
                }
            }
            Console.WriteLine(updateQs);

        }


    }
}
